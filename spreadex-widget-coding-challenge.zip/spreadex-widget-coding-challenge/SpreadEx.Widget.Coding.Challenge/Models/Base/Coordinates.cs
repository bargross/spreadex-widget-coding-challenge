namespace SpreadEx.Widget.Coding.Challenge.Models.Base;

public class Coordinates
{
    public int XCoordinate { get; set; }
    public int YCoordinate { get; set; }
}